// Wokwi Custom Chip - For information and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include "wokwi-api.h"

const uint8_t AHT10_I2C_ADDRESS = 0x38;

typedef enum {
  PIN_SCL,
  PIN_SDA,
  MAX_PINS,
} pins_t;

typedef enum {
  ST_IDLE,
  ST_WRITE_COMMAND,
  ST_WRITE_ARG1,
  ST_WRITE_ARG2,
  ST_READ_DATA,
} i2c_state_t;

typedef struct {
  pin_t pins[MAX_PINS];
  timer_t measure_timer_id;
  i2c_state_t state;

  uint8_t last_command;
  uint8_t read_buffer[6];
  uint8_t read_index;

  bool calibrated;
  bool busy;

  uint32_t temperature_attr;
  uint32_t humidity_attr;
} chip_state_t;

static bool on_i2c_connect(void *user_ctx, uint32_t address, bool read);
static uint8_t on_i2c_read(void *user_ctx);
static bool on_i2c_write(void *user_ctx, uint8_t data);
static void measure_ready_timer_event(void *user_data);

static uint8_t status_byte(const chip_state_t *chip) {
  uint8_t status = 0;
  if (chip->busy) {
    status |= 0x80;
  }
  if (chip->calibrated) {
    status |= 0x08;
  }
  return status;
}

static void fill_measurement_frame(chip_state_t *chip) {
  const float temp_c = attr_read_float(chip->temperature_attr);
  const float humidity = attr_read_float(chip->humidity_attr);

  float clamped_temp = temp_c;
  if (clamped_temp < -40.0f) {
    clamped_temp = -40.0f;
  } else if (clamped_temp > 85.0f) {
    clamped_temp = 85.0f;
  }

  float clamped_humidity = humidity;
  if (clamped_humidity < 0.0f) {
    clamped_humidity = 0.0f;
  } else if (clamped_humidity > 100.0f) {
    clamped_humidity = 100.0f;
  }

  const uint32_t humidity_raw = (uint32_t)((clamped_humidity / 100.0f) * 1048575.0f + 0.5f);
  const uint32_t temperature_raw = (uint32_t)(((clamped_temp + 50.0f) / 200.0f) * 1048575.0f + 0.5f);

  chip->read_buffer[0] = status_byte(chip);
  chip->read_buffer[1] = (humidity_raw >> 12) & 0xFF;
  chip->read_buffer[2] = (humidity_raw >> 4) & 0xFF;
  chip->read_buffer[3] = (uint8_t)(((humidity_raw & 0x0F) << 4) | ((temperature_raw >> 16) & 0x0F));
  chip->read_buffer[4] = (temperature_raw >> 8) & 0xFF;
  chip->read_buffer[5] = temperature_raw & 0xFF;
}

void chip_init() {
  chip_state_t *chip = calloc(1, sizeof(chip_state_t));

  chip->pins[PIN_SCL] = pin_init("SCL", INPUT);
  chip->pins[PIN_SDA] = pin_init("SDA", INPUT);

  chip->state = ST_IDLE;
  chip->last_command = 0;
  chip->read_index = 0;
  chip->calibrated = true;
  chip->busy = false;

  chip->temperature_attr = attr_init_float("temperature", 25.0f);
  chip->humidity_attr = attr_init_float("humidity", 50.0f);

  const timer_config_t measure_timer_config = {
    .callback = measure_ready_timer_event,
    .user_data = chip,
  };
  chip->measure_timer_id = timer_init(&measure_timer_config);

  fill_measurement_frame(chip);

  const i2c_config_t i2c_config = {
    .address = AHT10_I2C_ADDRESS,
    .scl = chip->pins[PIN_SCL],
    .sda = chip->pins[PIN_SDA],
    .connect = on_i2c_connect,
    .read = on_i2c_read,
    .write = on_i2c_write,
    .user_data = chip,
  };
  i2c_init(&i2c_config);
}

static void measure_ready_timer_event(void *user_data) {
  chip_state_t *chip = (chip_state_t *)user_data;
  chip->busy = false;
  fill_measurement_frame(chip);
}

static bool on_i2c_connect(void *user_ctx, uint32_t address, bool read) {
  chip_state_t *chip = (chip_state_t *)user_ctx;
  if (address != AHT10_I2C_ADDRESS) {
    return false;
  }

  if (read) {
    chip->state = ST_READ_DATA;
    chip->read_index = 0;
    chip->read_buffer[0] = status_byte(chip);
  } else {
    chip->state = ST_WRITE_COMMAND;
  }

  return true;
}

static uint8_t on_i2c_read(void *user_ctx) {
  chip_state_t *chip = (chip_state_t *)user_ctx;
  uint8_t value = 0xFF;

  if (chip->state != ST_READ_DATA) {
    return value;
  }

  if (chip->read_index < 6) {
    value = chip->read_buffer[chip->read_index++];
  }

  return value;
}

static bool on_i2c_write(void *user_ctx, uint8_t data) {
  chip_state_t *chip = (chip_state_t *)user_ctx;

  switch (chip->state) {
    case ST_WRITE_COMMAND:
      chip->last_command = data;
      if (data == 0xAC || data == 0xE1) {
        chip->state = ST_WRITE_ARG1;
      } else if (data == 0xBA) {
        chip->busy = false;
        chip->calibrated = true;
        fill_measurement_frame(chip);
        chip->state = ST_IDLE;
      } else {
        chip->state = ST_IDLE;
      }
      break;

    case ST_WRITE_ARG1:
      chip->state = ST_WRITE_ARG2;
      break;

    case ST_WRITE_ARG2:
      if (chip->last_command == 0xE1) {
        chip->calibrated = true;
        fill_measurement_frame(chip);
      } else if (chip->last_command == 0xAC) {
        chip->busy = true;
        chip->read_buffer[0] = status_byte(chip);
        timer_start(chip->measure_timer_id, 80000, false);
      }
      chip->state = ST_IDLE;
      break;

    default:
      chip->state = ST_IDLE;
      break;
  }

  return true;
}
